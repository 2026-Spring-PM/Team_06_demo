#!/bin/bash
# FarmPM 빌드 스크립트 (Mac Apple Silicon, sfml@2 기준)
# ※ src 폴더가 같은 위치에 있어야 빌드됩니다 (데모 제출본엔 소스 미포함)
cd "$(dirname "$0")/.."

if [ ! -d src ]; then
  echo "[FarmPM] src 폴더가 없어 빌드할 수 없습니다 (데모본은 실행파일만 포함)."
  exit 1
fi

echo "[FarmPM] 빌드 중..."
g++ -std=c++11 -I./include -I/opt/homebrew/opt/sfml@2/include \
  src/*.cpp -o build/FarmPM \
  -L/opt/homebrew/opt/sfml@2/lib \
  -lsfml-graphics -lsfml-window -lsfml-system

[ -f build/FarmPM ] && echo "[FarmPM] 빌드 성공!" || echo "[FarmPM] 빌드 실패"
