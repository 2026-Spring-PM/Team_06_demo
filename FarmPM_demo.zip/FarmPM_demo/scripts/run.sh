#!/bin/bash
# FarmPM 실행 스크립트
# 리소스(graphics, map)를 찾을 수 있도록 프로젝트 루트에서 실행
cd "$(dirname "$0")/.."

if [ ! -f build/FarmPM ]; then
  echo "[FarmPM] 실행파일이 없습니다. 먼저 빌드하세요:"
  echo "  bash scripts/build.sh"
  exit 1
fi

./build/FarmPM
